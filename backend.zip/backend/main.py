from fastapi import FastAPI
from fastapi.responses import JSONResponse
import instaloader

app = FastAPI()

@app.get("/verify/{username}")
async def verify_instagram_account(username: str):
    try:
        # Create an instance of Instaloader
        L = instaloader.Instaloader()

        # Load the profile for the given username
        profile = instaloader.Profile.from_username(L.context, username)

        # Check if the account is private or not
        if profile.is_private:
            return JSONResponse(content={"status": "Fake Account"}, status_code=200)

        return JSONResponse(content={"status": "Real Account"}, status_code=200)
    
    except Exception as e:
        return JSONResponse(content={"status": "Error", "message": str(e)}, status_code=400)
